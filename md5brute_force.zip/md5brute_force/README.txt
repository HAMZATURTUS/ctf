in order to decrypt the cipher, we need to understand what the encryption file does

for each character, the file will:
1. left shift the ascii value by 7 bits
2. XOR the value by a secret random number (SRN)
3. convert the new number into a string and encode it to bytes
4. convert the bytes value into md5 hash format



so to decrypt we have to work with each character separately, so we can start by splitting the ciphertext into blocks of 32: each block representing a character in the flag

to find the secret random number, we have to start with the first character, which we already know will be a 'P'. so we follow the steps shown above except for step 2, which we will have to brute force.

the code left shifts the ascii value of 'P' by 7 bits. now we have to try to XOR 'P' with every number between 1 and K and whichever value gives us the cipher after following steps 3 and 4, will be the secret number.

i chose K to be 50000 because the ascii of 'P' is 13 bits and i figured that the secret number's value would not be far off as the final XOR will have to be a similar value to P so i chose a value that was 16 bits long.

the secret number is 32768 or 2^15
the code that found the secret number is commented out in solve.txt

now that we have the secret number, we can brute force the remaining characters by trying every possible character from chr(1) to chr(256) and concluding that a character is part of the flag if the hash that i got by trying its value matched the hash of the cipher text.

the flag is: PlayGroundsCTF{Cr4ck_Th1s_K3y_B4by}